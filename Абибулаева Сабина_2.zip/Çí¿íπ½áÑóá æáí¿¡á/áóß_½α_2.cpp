// реализовать программу для конвертации 16-битного формата числа с плавающей запятой в формате IEEE 754 в десятичное

#include <iostream> 
#include <cmath>   
#include <iomanip> 
#include <limits>  

using namespace std;

void sabi_abi_v1_task6() 
{
    unsigned short ieee754; 

    cout << "input 16 cc num (0x3C00 and IEEE 754): "; 
    cin >> hex >> ieee754; 

    int sign = (ieee754 >> 15) & 0x1; 
    int exponent = (ieee754 >> 10) & 0x1F; 
    int mantissa = ieee754 & 0x3FF; 

    float decimal; 

    if (exponent == 0) 
    { 
        decimal = (sign ? -1 : 1) * (mantissa / 1024.0f) * pow(2, -14); 
    
    } 
    else if (exponent == 31) 
    { 
        decimal = (mantissa == 0) ? (sign ? -numeric_limits<float>::infinity() : numeric_limits<float>::infinity()) : numeric_limits<float>::quiet_NaN();

    } 
    else 
    { 
        decimal = (sign ? -1 : 1) * (1 + mantissa / 1024.0f) * pow(2, exponent - 15); 
        
    }

    cout << "decimal num: " << decimal << "\n"; 
}


int main() 
{
    sabi_abi_v1_task6();
    return 0;
}

